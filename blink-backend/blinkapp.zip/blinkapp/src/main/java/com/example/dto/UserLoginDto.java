package com.example.dto;

import lombok.Data;

@Data
public class UserLoginDto {
    private String email;
    private String password;
}
