package com.example.controller;

import com.example.dto.UserProfileDto;
import com.example.service.EmailService;
import com.example.service.UserService;
import com.example.entity.User;
import com.example.repository.UserRepository;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/user")
@CrossOrigin(origins = "http://localhost:5173")
public class UserController {

    @Autowired
    private UserService userService;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private EmailService emailService;

    @GetMapping("/{email}")
    public UserProfileDto getProfile(@PathVariable String email) {
        return userService.getProfile(email);
    }

    @PutMapping("/{email}")
    public String updateProfile(@PathVariable String email, @RequestBody UserProfileDto dto) {
        return userService.updateProfile(email, dto);
    }
    
    @PostMapping("/signup")
    public User registerUser(@RequestBody User user) {
        return userRepository.save(user);
    }
  

    private Map<String, String> otpStorage = new HashMap<>();

    @PostMapping("/send-otp")
    public ResponseEntity<String> sendOtp(@RequestBody Map<String, String> request) {
        String email = request.get("email");
        String otp = String.valueOf((int)(Math.random() * 900000) + 100000); // 6-digit OTP
        otpStorage.put(email, otp);
        emailService.sendOtpEmail(email, otp);
        return ResponseEntity.ok("OTP sent to " + email);
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<String> verifyOtp(@RequestBody Map<String, String> request) {
        String email = request.get("email");
        String otp = request.get("otp");

        if (otpStorage.containsKey(email) && otpStorage.get(email).equals(otp)) {
            otpStorage.remove(email);
            return ResponseEntity.ok("OTP verified successfully!");
        }
        return ResponseEntity.badRequest().body("Invalid or expired OTP!");
    }
}


